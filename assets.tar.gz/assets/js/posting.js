function onClickReclassify()
{
	//*****THIS IS COMPULSORY SECURITY SETUP FOR SENDING DATA TO A DJANGO SERVER*******
	var csrftoken = $.cookie('csrftoken');

	function csrfSafeMethod(method) {
		// these HTTP methods do not require CSRF protection
		return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
	}

	$.ajaxSetup({beforeSend: function(xhr, settings) {
		if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
		xhr.setRequestHeader("X-CSRFToken", csrftoken);
	}
	}
	});

	//**************************************************************************

	//Posting data from a button using the ID of that button to a URL
	document.getElementById("targets_reclass_button").onclick = function () {
			$.post("../reclassify/", {
			reclassify: "key",
			category: "targets"
			} );
	};

	document.getElementById("diagnoses_reclass_button").onclick = function () {
			$.post("../reclassify/", {
			reclassify: "key",
			category: "diagnoses"
			} );
	};

};